from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Student
# Create your views here.
def all_student_view(request):
    students = Student.objects.all()
    
    context = {
        'students' : students
    }
    
    return render(request, 'display-student.html',context)


def student_details_view(request,id):
    try:
        student = Student.objects.get(id=id)

    except Student.DoesNotExist:
        return HttpResponse('Student ID does not exist')     
    context = {
        'student' : student
    }
    
    return render(request, 'student-details.html',context)

def create_student_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        roll = request.POST.get('roll')
        marks = request.POST.get('marks')
        course = request.POST.get('course')
        admsnType = request.POST.get('admsnType')
        
        print('name:',name)
        print('roll:',roll)
        print('marks',marks)
        print('course',course)
        
        Student.objects.create(name = name, roll = roll, marks = marks, course = course, admsnType = admsnType)
        
        return redirect('home')
    
    return render(request, 'create-student.html')
        
def update_student_view(request,id):
    try:
        student = Student.objects.get(id=id)

    except Student.DoesNotExist:
        return HttpResponse('Student ID does not exist') 

    if request.method == 'POST':
        name = request.POST.get('name')
        roll = request.POST.get('roll')
        marks = request.POST.get('marks')
        course = request.POST.get('course')
        admsnType = request.POST.get('admsnType')
        
        student.name = name
        student.roll = roll
        student.course = course
        student.marks = marks
        student.admsnType = admsnType
        student.save()
    
        return redirect('home')
    context = {
        'student' : student
    }
    
    return render(request, 'update-student.html',context)

def delete_student_view(request,id):
    try:
        student = Student.objects.get(id=id)

    except Student.DoesNotExist:
        return HttpResponse('Student ID does not exist') 
    
    if request.method == "POST":
        student.delete()
        return redirect('home')
    context = {
        'student' : student
    }
    
    return render(request, 'delete-student.html',context)   

























