from django.urls import path
from . import views

urlpatterns = [
    path('',views.all_student_view,name='home' ),
    path('detail/<int:id>/', views.student_details_view, name='detail'),
    path('create/',views.create_student_view, name='create'),
    path('update/<int:id>/',views.update_student_view, name = 'update'),
    path('delete-student/<int:id>/',views.delete_student_view, name="delete"),
]
