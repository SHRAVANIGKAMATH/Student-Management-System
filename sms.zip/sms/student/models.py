from django.db import models

# Create your models here.

class Student(models.Model):
    name = models.CharField(max_length=50)
    roll = models.IntegerField()
    marks = models.FloatField()
    course = models.CharField(max_length=200)
    admsnType = models.CharField(max_length=200)
    
    def __str__(self):
        return self.name
    

        